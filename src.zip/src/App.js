import logo from "./logo.svg";
import "./App.css";
import GlassesList from "./components/GlassesList";

function App() {
  return (
    <div>
      <GlassesList />
    </div>
  );
}

export default App;
