import React, { Component } from "react";
import ModelImg from "./img/model.jpg";
import style from "./Model.module.css";

export default class Modal extends Component {
  render() {
    const { url } = this.props.selectedItem;
    return (
      <div className="item">
        {/* <img src={ModelImg} alt="" /> */}
        <img src={url} alt="" />
      </div>
    );
  }
}
